<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PagesController extends Controller
{
    //
	public function index(){
		//return "hai mariya";
		$name="mariya";
		//return view('Pages.index',compact('name'));
		return view('Pages.index')->with('titles',$name);
		}
	public function about(){
		//return "hai mariya";
		return view('Pages.about');
	}
	public function service(){
		//return "hai mariya";
		return view('Pages.service');
	}
	
}
