<form method="post" action="{{route('datas.store')}}">
@csrf

<table>
<tr><td>Title</td><td><input type="text" name="title"></td></tr>
<tr><td>Body</td><td><input type="text" name="body"></td></tr>

<tr><td><td><input type="submit" value="ADD"></td></td></tr>
</table>
</form>