<form method="post" action="{{route('datas.update',$value1->id)}}">
@csrf
@method('PATCH')

<table>
<tr><td>Title</td><td><input type="text" name="title" value="{{$value1->title}}"></td></tr>
<tr><td>Body</td><td><input type="text" name="body" value="{{$value1->body}}"></td></tr>

<tr><td><td><input type="submit" value="UPDATE"></td></td></tr>
</table>
</form>