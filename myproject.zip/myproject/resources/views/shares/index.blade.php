@extends('Layouts.app')
@section('content')
<html>
<body>
<table border="1">

<tr><td>Id</td><td>Title</td><td>Body</td><td>Edit</td><td>Delete</td></tr>
@foreach($share as $values)
<tr>
<td>{{$values->id}}</td>
<td>{{$values->title}}</td>
<td>{{$values->body}}</td>
<td><a href="{{route('datas.edit',$values->id)}}">Edit</a></td>
<td><form action="{{ route('datas.destroy',$values->id)}}" method="post">
@csrf
@method('DELETE')
<button type="submit">Delete</button>
</form>
</td>
</tr>
@endforeach
</table>
</body>
</html>
@endsection
