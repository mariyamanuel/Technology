<?php $__env->startSection('content'); ?>
<html>
<body>
<table border="1">

<tr><td>Id</td><td>Title</td><td>Body</td><td>Edit</td><td>Delete</td></tr>
<?php $__currentLoopData = $share; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $values): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
<td><?php echo e($values->id); ?></td>
<td><?php echo e($values->title); ?></td>
<td><?php echo e($values->body); ?></td>
<td><a href="<?php echo e(route('datas.edit',$values->id)); ?>">Edit</a></td>
<td><form action="<?php echo e(route('datas.destroy',$values->id)); ?>" method="post">
<?php echo csrf_field(); ?>
<?php echo method_field('DELETE'); ?>
<button type="submit">Delete</button>
</form>
</td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
</body>
</html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>