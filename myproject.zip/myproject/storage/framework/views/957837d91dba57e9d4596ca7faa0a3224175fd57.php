<form method="post" action="<?php echo e(route('datas.update',$value1->id)); ?>">
<?php echo csrf_field(); ?>
<?php echo method_field('PATCH'); ?>

<table>
<tr><td>Title</td><td><input type="text" name="title" value="<?php echo e($value1->title); ?>"></td></tr>
<tr><td>Body</td><td><input type="text" name="body" value="<?php echo e($value1->body); ?>"></td></tr>

<tr><td><td><input type="submit" value="UPDATE"></td></td></tr>
</table>
</form>