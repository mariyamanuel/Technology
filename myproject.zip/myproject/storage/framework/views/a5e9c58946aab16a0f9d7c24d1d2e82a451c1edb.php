<?php $__env->startSection('content'); ?>

<h1>Home</h1>
<h1><?php echo e($titles); ?></h1>
<p>Hello</p>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>