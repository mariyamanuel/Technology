<form method="post" action="<?php echo e(route('datas.store')); ?>">
<?php echo csrf_field(); ?>

<table>
<tr><td>Title</td><td><input type="text" name="title"></td></tr>
<tr><td>Body</td><td><input type="text" name="body"></td></tr>

<tr><td><td><input type="submit" value="ADD"></td></td></tr>
</table>
</form>